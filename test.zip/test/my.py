import sys
import os
import platform

print("Hello world")

for x in xrange(1,10):
	print("x = ",x)


print("{} is me".format("anxi"))


inputs = input("please input a number:")
print("the number you input is:",inputs)

#print("show version ",sys.version)
