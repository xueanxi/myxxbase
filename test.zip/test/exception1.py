#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Date    : 2018-01-20 10:51:08
# @Author  : Your Name (you@example.org)
# @Link    : http://example.org
# @Version : $Id$


input("Enter somethings:")
print("what your input is:")
